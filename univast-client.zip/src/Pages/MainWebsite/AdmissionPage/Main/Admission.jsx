import AdmissionMain from "../Sections/AdmissionMain/AdmissionMain";
import AdmissionRequirement from "../Sections/AdmissionRequirement/AdmissionRequirement";


const Admission = () => {
  return (
    <div>
      <AdmissionMain></AdmissionMain>
      <AdmissionRequirement></AdmissionRequirement>
    </div>
  );
};

export default Admission;