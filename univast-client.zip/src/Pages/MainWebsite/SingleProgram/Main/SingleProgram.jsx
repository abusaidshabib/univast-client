const SingleProgram = () => {
    return (
        <div>
            
        </div>
    );
};

export default SingleProgram;