const Course_Taught = () => {
  return (
    <div className="flex gap-10">
      <div></div>
      <div></div>
    </div>
  );
};

export default Course_Taught;
