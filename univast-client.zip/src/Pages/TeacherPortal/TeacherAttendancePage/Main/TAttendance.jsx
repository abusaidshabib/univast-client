import TMainAttendance from "../Section/MainAttendanceTable/TMainAttendance";

const TAttendance = () => {
  return (
    <div className="min-h-[calc(100vh-80px)] w-full bg-gray-200 p-5">
      <TMainAttendance></TMainAttendance>
    </div>
  );
};

export default TAttendance;
