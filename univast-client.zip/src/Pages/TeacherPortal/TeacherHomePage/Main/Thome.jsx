import TClassRoutine from "../Sections/TClassRoutine/TClassRoutine";
import TProfileCard from "../Sections/TProfileCard/TProfileCard";

const Thome = () => {
  return (
    <div className="grid grid-cols-4 gap-5 p-5 bg-gray-200 min-h-[calc(100vh-80px)] text-gray-900">
      <div className="col-span-3 grid gap-5">
        <div>
          <TClassRoutine />
        </div>
      </div>
      <TProfileCard></TProfileCard>
    </div>
  );
};

export default Thome;
