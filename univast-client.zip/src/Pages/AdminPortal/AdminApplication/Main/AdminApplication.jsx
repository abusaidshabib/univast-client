const AdminApplication = () => {
  return (
    <div className="grid grid-cols-4 gap-5 p-5 bg-gray-200 min-h-[calc(100vh-80px)] text-gray-900"></div>
  );
};

export default AdminApplication;
