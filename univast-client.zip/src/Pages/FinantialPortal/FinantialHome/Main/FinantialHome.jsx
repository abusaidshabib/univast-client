const FinantialHome = () => {
    return (
        <div>
            
        </div>
    );
};

export default FinantialHome;