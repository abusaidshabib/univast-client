import SMainGrades from "../Sections/SMainGrades";

const SGrades = () => {
  return (
    <div className="min-h-[calc(100vh-80px)] w-full bg-gray-200 p-5">
      <SMainGrades></SMainGrades>
    </div>
  );
};

export default SGrades;
