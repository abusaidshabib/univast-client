const ResourceNotice = () => {
    return (
        <div>
            
        </div>
    );
};

export default ResourceNotice;