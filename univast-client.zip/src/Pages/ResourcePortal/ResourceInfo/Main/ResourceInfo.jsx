const ResourceInfo = () => {
    return (
        <div>
            
        </div>
    );
};

export default ResourceInfo;