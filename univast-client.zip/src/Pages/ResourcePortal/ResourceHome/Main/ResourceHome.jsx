const ResourceHome = () => {
    return (
        <div>
            
        </div>
    );
};

export default ResourceHome;