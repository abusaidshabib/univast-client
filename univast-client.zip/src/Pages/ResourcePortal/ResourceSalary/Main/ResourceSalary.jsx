const ResourceSalary = () => {
    return (
        <div>
            
        </div>
    );
};

export default ResourceSalary;