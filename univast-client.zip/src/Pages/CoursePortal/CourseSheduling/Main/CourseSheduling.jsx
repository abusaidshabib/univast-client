const CourseSheduling = () => {
    return (
        <div>
            
        </div>
    );
};

export default CourseSheduling;