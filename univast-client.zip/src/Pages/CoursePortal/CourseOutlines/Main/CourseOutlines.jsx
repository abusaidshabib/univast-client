const CourseOutlines = () => {
    return (
        <div>
            
        </div>
    );
};

export default CourseOutlines;