const ApplicantHome = () => {
    return (
        <div>
            
        </div>
    );
};

export default ApplicantHome;