const AssignTeacher = () => {
    return (
        <div>
            
        </div>
    );
};

export default AssignTeacher;