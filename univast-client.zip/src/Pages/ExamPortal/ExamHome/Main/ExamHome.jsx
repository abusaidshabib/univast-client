const ExamHome = () => {
  return <div></div>;
};

export default ExamHome;

// Show every class and exam routines
