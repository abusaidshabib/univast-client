const Registration = () => {
    return (
        <div>
            
        </div>
    );
};

export default Registration;